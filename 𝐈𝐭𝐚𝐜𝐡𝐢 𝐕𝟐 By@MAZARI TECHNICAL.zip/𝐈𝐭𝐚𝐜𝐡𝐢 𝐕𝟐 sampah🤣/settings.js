const fs = require('fs')

//===========================//

const {
proto, delay, getContentType
} = require('./lib/myfunction')

//===========================//

global.d = new Date()
global.calender = d.toLocaleDateString('id')

//===========================//

//================[. GLOBAL OWNER ]================//

global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6289635946324', "6289654498303"] //change na krna<
global.ownMain = '6289654498303' //change na krna phr on nhi hoga bot
global.NamaOwner = 'ZutXl' //change na krna
global.sessionName = 'ZutXl'
global.connect = true // khud connect ho jaye gi
global.namabot = '𝐈𝐭𝐚𝐜𝐡𝐢' //change na krna
global.author = '𝐈𝐭𝐚𝐜𝐡𝐢' //change na krna
global.packname = '𝐈𝐭𝐚𝐜𝐡𝐢' //change na krna
global.yt = '-' //subscribe kro
global.ch = 'https://t.me/hLYfGnNJUPQ3NDI1'

//================[. GLOBAL RESPON ]================//
global.mess = { // In ko bilkul na chherna
 ingroup: ' 𝙺𝚑𝚞𝚜𝚞𝚜 𝙶𝚛𝚘𝚞𝚙 ',
 admin: '𝙺𝚑𝚞𝚜𝚞𝚜 𝙰𝚍𝚖𝚒𝚗',
 owner: '𝙺𝚑𝚞𝚜𝚞𝚜 𝙾𝚠𝚗𝚎𝚛',
 premium: '𝙺𝚑𝚞𝚜𝚞𝚜 𝙿𝚛𝚎𝚖𝚒𝚞𝚖',
 seller: '𝙺𝚑𝚞𝚜𝚞𝚜 𝚂𝚎𝚕𝚕𝚎𝚛',
 usingsetpp: `𝙺𝚑𝚞𝚜𝚞𝚜 𝙾𝚠𝚗𝚎𝚛 𝚄𝚗𝚝𝚞𝚔 𝙼𝚎𝚗𝚐𝚐𝚞𝚗𝚊𝚔𝚊𝚗 𝚂𝚎𝚝𝚙𝚙`,
 wait: '𝙿𝚛𝚘𝚜𝚎𝚜 𝚈𝚊 𝙹𝚊𝚗𝚐𝚊𝚗 𝚂𝚙𝚊𝚖,𝚠𝚊𝚒𝚝',
 success: '𝚂𝚞𝚌𝚌𝚎𝚜 𝙱𝚛𝚘',
 bugsuc: '𝚂𝚞𝚌𝚌𝚎𝚜 𝚂𝚎𝚗𝚍𝚍𝚒𝚗𝚐 𝙱𝚞𝚐',
 bugrespon: '𝙲𝚎𝚔 𝚊𝚓𝚊'
}

//===========================//

// #@whiskeysockets/baileys ^6.6.0
global.autOwn = 'req(62-8S57547ms11).287p'
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
	delete require.cache[file]
	require(file)
})